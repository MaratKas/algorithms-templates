from typing import List
# ID 72847757


def get_best_zero(street: List[int], n: int) -> List[int]:
    """Построекие карты с домов и пустых участков."""
    index_zero = []
    i = 0
    while i <= n:
        try:
            index = street.index(0, i, n)
            i = index
            index_zero.append(index)
        except ValueError:
            break
        i += 1
    street_zero = []
    key = 0
    s = 0
    for ind in index_zero:
        s += 1
        delta = ind - key
        if s == 1:
            street_zero.extend(list(range(delta, -1, -1)))
            key = ind
        if s > 1 and s <= n:
            if ind - key > 1:
                delta_up = delta//2
                street_zero.extend(list(range(1, delta_up + 1, 1)))
                delta = delta - delta_up
                key = ind
                street_zero.extend(list(range(delta, -1, -1)))
            else:
                if ind - key == 1:
                    street_zero.append(1)
                street_zero.append(0)
                key = ind
        key += 1
    if key < n:
        delta_up = n - key
        street_zero.extend(list(range(1, delta_up + 1, 1)))
    return street_zero


def read_input() -> List[int]:
    """Вводные данные."""
    n = int(input())
    street = list(map(int, input().strip().split()))
    return street, n


street, n = read_input()
result = get_best_zero(street, n)
print(" ".join(map(str, result)))
