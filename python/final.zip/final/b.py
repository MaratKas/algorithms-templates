from typing import List
import re
# ID 72945061


def sleight_of_hand(keyboard: List[int], k: int) -> int:
    """Проверка получения баллов."""
    t = []
    t = list(set(re.findall(r'\d', keyboard)))
    ball = 0
    for i in t:
        if k * 2 >= keyboard.count(i, 0, len(keyboard)):
            ball += 1
    return ball


def read_input() -> List[int]:
    """Вводные данные."""
    k = int(input())
    keyboard = ''
    for i in range(4):
        keyboard = keyboard + input()
    return keyboard, k


keyboard, k = read_input()
print(sleight_of_hand(keyboard, k))
