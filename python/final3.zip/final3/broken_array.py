# 77187397

from typing import List, Tuple


def broken_search(nums: list, target: int) -> int:
    """Поиск в сломанном массиве."""
    left = 0
    right = len(nums) - 1
    result = -1
    while left <= right:
        mid = (left + right)//2
        if nums[mid] == target:
            result = mid
            break
        if nums[left] <= nums[mid]:
            if nums[left] <= target < nums[mid]:
                right = mid
                continue
            else:
                left = mid+1
                continue
        elif nums[mid] <= nums[left]:
            if nums[mid] < target <= nums[left]:
                left = mid+1
                continue
            else:
                right = mid
                continue
    return result


def read_input() -> Tuple[int, int, List[int]]:
    """Ввод тестовых данных."""
    n = int(input())
    m = int(input())
    mass_list = list(map(int, input().strip().split()))
    return n, m, mass_list


if __name__ == '__main__':
    n, m, mass_list = read_input()
    print(broken_search(mass_list, m))