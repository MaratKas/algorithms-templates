# 77450107
from typing import Tuple
from random import randint


def effective_quick_sort(rating: list, left: int, right: int) -> list:
    """Эффективная сортировка"""
    if left >= right:
        return -1
    x = rating[randint(left, right)]
    i = left
    j = right
    while i <= j:
        while rating[i] < x:
            i += 1
        while rating[j] > x:
            j -= 1
        if i <= j:
            rating[i], rating[j] = rating[j], rating[i]
            i += 1
            j -= 1
    effective_quick_sort(rating, left, j)
    effective_quick_sort(rating, i, right)
    return rating


def reformat(login: str, solutions: int, staff: int) -> list:
    """Форматирование данных."""
    return [-int(solutions), int(staff), login]


def read_input() -> Tuple[int, list]:
    """Ввод тестовых данных."""
    member = int(input())
    rating = [reformat(*input().split()) for _ in range(member)]
    return member, rating


if __name__ == '__main__':
    member, rating = read_input()
    left = 0
    right = member - 1
    if member == 1:
        print(rating[0][2])
    else:
        result = effective_quick_sort(rating, left, right)
        for item in result:
            print(item[2])
