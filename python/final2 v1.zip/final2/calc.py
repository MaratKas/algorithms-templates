# 74601651
LOCAL = True

if LOCAL:
    class Stack:
        """Клас стек-калькулятор."""
        def __init__(self):
            self.items = []
            self.size = 0

        def push(self, item: int):
            self.items.append(item)
            self.size += 1

        def pop(self):
            if self.size > 0:
                self.size -= 1
                return self.items.pop()
            else:
                return print('error')

        def peek(self):
            return self.items[-1]

        def addition(self):
            self.push(int(self.pop() + self.pop()))

        def subtraction(self):
            a, b = self.pop(), self.pop()
            self.push(int(b - a))

        def multiplication(self):
            self.push(int(self.pop() * self.pop()))

        def division(self):
            a, b = self.pop(), self.pop()
            self.push(int(b // a))


if __name__ == '__main__':
    calc_cmd = []
    calc_cmd = input().split()
    stack_arg = Stack()
    for _, arg in enumerate(calc_cmd):
        if arg in "+-*/":
            if arg == "+":
                stack_arg.addition()
            elif arg == "-":
                stack_arg.subtraction()
            elif arg == "*":
                stack_arg.multiplication()
            elif arg == "/":
                stack_arg.division()
        else:
            stack_arg.push(int(arg))
    print(stack_arg.peek())
