# 74521250
class MyDeque:
    """
    Клас ДЕК.
    push_back(value) – добавить элемент в конец дека.
    push_front(value) – добавить элемент в начало дека.
    pop_front() – вывести первый элемент дека и удалить его.
    pop_back() – вывести последний элемент дека и удалить его.
    """
    def __init__(self, size_queue):
        self.deque = [None] * size_queue
        self.max_n = size_queue
        self.head = 0
        self.tail = 0
        self.size_len = 0

    def is_empty(self):
        return self.size_len == 0

    def push_back(self, x):
        if self.size_len != self.max_n:
            if self.size_len > 0:
                self.tail = (self.tail + 1) % self.max_n
            self.deque[self.tail] = x
            self.size_len += 1
        else:
            print("error")

    def push_front(self, x):
        if self.size_len != self.max_n:
            if self.size_len > 0:
                if self.head == 0:
                    self.head = self.max_n-1
                else:
                    self.head -= 1
            self.deque[self.head] = x
            self.size_len += 1
        else:
            print("error")

    def pop_front(self):
        if self.is_empty():
            print("error")
        else:
            x = self.deque[self.head]
            self.deque[self.head] = None
            if self.size_len > 1:
                self.head = (self.head + 1) % self.max_n
            self.size_len -= 1
            print(x)

    def pop_back(self):
        if self.is_empty():
            print("error")
        else:
            x = self.deque[self.tail]
            self.deque[self.tail] = None
            if self.size_len > 1:
                if self.tail == 0:
                    self.tail = self.max_n-1
                else:
                    self.tail -= 1
            self.size_len -= 1
            print(x)


if __name__ == '__main__':
    amount_cmd = int(input())
    size_deque = int(input())
    deque = MyDeque(size_deque)
    for _ in range(amount_cmd):
        cmd = input().split()
        cd = cmd[0]
        if cd == "push_front":
            deque.push_front(int(cmd[1]))
        elif cd == "push_back":
            deque.push_back(int(cmd[1]))
        elif cd == "pop_front":
            deque.pop_front()
        elif cd == "pop_back":
            deque.pop_back()
